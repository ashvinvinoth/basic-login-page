package com.example.ashvinvinoth.basiclogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SecondPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);
    }
}
